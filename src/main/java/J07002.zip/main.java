/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vu
 */
import java.util.*;
import java.io.*;

public class main {
    public static void main(String[] args) throws FileNotFoundException{
            Scanner sc = new Scanner(new File("DATA.in"));
            long sum = 0;
            while(sc.hasNext()){
               try{
                   int a = Integer.parseInt(sc.next());
                   sum += a;
               } catch (NumberFormatException e){
                   
               }
            }
            System.out.println(sum);
            sc.close();
    }
}
