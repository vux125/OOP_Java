/**
 *
 * @author Vu
 */
import java.util.*;
import java.io.*;
import com.mycompany.mavenproject1.J07029;

public class main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        List<Integer> ls = new ArrayList<>();
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("DATA.in"));
        ls = (ArrayList<Integer>) in.readObject();
        ls.sort(Collections.reverseOrder());
        List<Integer> ngto = new ArrayList<>();
        Integer[] lss = new Integer[100001];
        for(Integer num : ls){
            lss[num]++;
        }
        for(int i=1 ; i <100001; i++){
            if(J07029.isPrime(i) && lss[i]!= 0){
                System.out.println(i + " " + lss[i]);
            }
        }   
    }
}

