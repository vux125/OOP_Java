/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Vu
 */
import java.util.*;
import java.text.*;

public class J05005 implements Comparable<J05005> {
    private String msv, name, cls, gpa;
    private Date birthDay;

    
    public J05005(int n, String name, String cls, String birthDay, float gpa){
        this.msv = "B20DCCN" + String.format("%03d", n);
        this.name = formatName(name);
        this.cls = cls;
        try {
            this.birthDay = new SimpleDateFormat("dd/MM/yyyy").parse(birthDay);      
        } catch (Exception e) {
            e.printStackTrace();
        } 
        this.gpa = String.format("%.2f", gpa);
    }
    public String formatName(String name){
        name = name.toLowerCase();
        String[] words = name.trim().split("\\s+");
        
        StringBuilder formatted = new StringBuilder();
        
        for(String word:words){
            if(word.length() > 0){
                formatted.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1))
                        .append(" ");
            }
        }
        return formatted.toString().trim();
    }
    
    @Override
    public int compareTo(J05005 other){
        return Float.compare(Float.parseFloat(other.gpa),Float.parseFloat(this.gpa));
    }
    @Override
    public String toString(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return this.msv+" "+this.name+" "+this.cls+" "+sdf.format(this.birthDay)+" "+this.gpa;
    }
}

