/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Vu
 */
import java.util.*;
import java.text.*;

public class J05003 {
    private String msv, name, cls, gpa;
    private Date birthDay;

    
    public J05003(int n, String name, String cls, String birthDay, float gpa){
        this.msv = "B20DCCN" + String.format("%03d", n);
        this.name = name;
        this.cls = cls;
        try {
            this.birthDay = new SimpleDateFormat("dd/MM/yyyy").parse(birthDay);      
        } catch (Exception e) {
            e.printStackTrace();
        } 
        this.gpa = String.format("%.2f", gpa);
    }
    @Override
    public String toString(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return this.msv+" "+this.name+" "+this.cls+" "+sdf.format(this.birthDay)+" "+this.gpa;
    }
}

