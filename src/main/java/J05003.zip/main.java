/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vu
 */
import com.mycompany.mavenproject1.J05003;
import java.util.*;

public class main {
    public static Scanner sca = new Scanner(System.in);
    public static void main(String[] args){
        int t = sca.nextInt();
        sca.nextLine();
        ArrayList<J05003> students = new ArrayList<J05003>();
        for(int i=1 ; i<= t ;i++){
            students.add(new J05003(i, sca.nextLine(),sca.next(), sca.next(), sca.nextFloat()));
            sca.nextLine();
        }
        for(J05003 student:students){
            System.out.println(student);
        }
    }
}
