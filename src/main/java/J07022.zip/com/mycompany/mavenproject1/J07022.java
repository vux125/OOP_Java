/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Vu
 */
public class J07022 {
    public static void notInteger(String str){
        try{
            Integer so = Integer.parseInt(str);
        } catch(NumberFormatException e){
            System.out.print(str+" ");
        }
    }
}
