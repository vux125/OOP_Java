/**
 *
 * @author Vu
 */
import com.mycompany.mavenproject1.J05009;
import java.util.*;

public class main {
    public static Scanner sca = new Scanner(System.in);
    public static void main(String[] args){
        int t = sca.nextInt();
        sca.nextLine();
        ArrayList<J05009> thisinh = new ArrayList<J05009>();
        for(int i=1 ; i<= t ;i++){
            thisinh.add(new J05009(i, sca.nextLine(),sca.nextLine(),Float.parseFloat(sca.nextLine()),Float.parseFloat(sca.nextLine()),Float.parseFloat(sca.nextLine())));
        }
        Collections.sort(thisinh);
        float maxPoin = thisinh.get(0).getSumPoin();
        for(J05009 ts:thisinh){
            if(ts.getSumPoin() == maxPoin){
                System.out.println(ts);
            }
        }
    }
}

