/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vu
 */
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class main {
    public static void main(String[] args) throws FileNotFoundException{
            Scanner sc = new Scanner(new File("DATA.in"));
            Map<Integer,Integer> count = new TreeMap<Integer, Integer>();
            while(sc.hasNextInt()){
               int a = sc.nextInt();
               count.put(a,count.getOrDefault(a, 0) +1 );
            }
            sc.close();
            
            for(Map.Entry<Integer,Integer> entry : count.entrySet()){
                System.err.println(entry.getKey() + " " + entry.getValue());
            }
    }
}
