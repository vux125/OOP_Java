/**
 *
 * @author Vu
 */
import java.util.*;
import java.io.*;
import com.mycompany.mavenproject1.J07021;

public class main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("DATA.in"));
        while(sc.hasNextLine()){
            String name = sc.nextLine();
            if(name.equals("END")) break;
            System.out.println(J07021.formatName(name));
        }
    }
}

