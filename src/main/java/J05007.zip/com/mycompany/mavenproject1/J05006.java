/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Vu
 */
import java.util.*;
import java.text.*;

public class J05006 implements Comparable<J05006>{
    private String mnv, name, sex, address, tax_code;
    private Date birthDay, sign_date;

    
    public J05006(int n, String name, String sex, String birthDay, String address, String tax_code, String sign_date){
        this.mnv = String.format("%05d", n);
        this.name = name;
        this.sex = sex;
        try {
            this.birthDay = new SimpleDateFormat("dd/MM/yyyy").parse(birthDay);      
            this.sign_date =  new SimpleDateFormat("dd/MM/yyyy").parse(sign_date); 
        } catch (Exception e) {
            e.printStackTrace();
        } 
        this.address = address;
        this.tax_code = tax_code;
        
    }
    @Override
    public int compareTo(J05006 other){
        return this.birthDay.compareTo(other.birthDay);
    }
    @Override
    public String toString(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return this.mnv + " " + this.name + " " + this.sex + " " + sdf.format(this.birthDay) + " " + this.address + " " +this.tax_code + " " + sdf.format(this.sign_date) ;
    }
}

