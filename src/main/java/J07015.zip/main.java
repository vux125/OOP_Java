/**
 *
 * @author Vu
 */
import com.mycompany.mavenproject1.J07015;
import java.util.*;
import java.io.*;

public class main {
    public static void main(String[] args) throws IOException, ClassNotFoundException{
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("SONGUYEN.in"));
        ArrayList<Integer> arr = new ArrayList<Integer> ();
        arr = (ArrayList<Integer>) in.readObject();
        int ar[] = new int[10001];
        for(int i : arr){
            ar[i] ++;
        }
        for(int i=1; i <10001 ; i++){
            if(ar[i] != 0 && J07015.isPrime(i)){
                System.out.println(i + " " + ar[i]);
            }
        }
    }
}

