/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Vu
 */
import java.util.*;
import java.text.*;

public class J07015 {
   public static boolean isPrime(int n){
       if(n < 2) return false;
       for(int i = 2;i <= Math.sqrt(n); i++){
           if(n % i == 0){
               return false;
           }
       }
       return true;
   }
}
