/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Vu
 */
import java.util.*;
import java.text.*;

public class Pair<K, V> {
   private int so1;
   private int so2;
   public Pair(int so1, int so2){
       this.so1 = so1;
       this.so2 = so2;
   }
   public boolean isPrime(){
        if((int)this.so1 < 2) return false;
        for(int i=2 ; i <=Math.sqrt((int)this.so1); i ++){
            if((int)this.so1 % i ==0) return false;
        }
        if((int)this.so2 < 2) return false;
        for(int i=2 ; i <=Math.sqrt((int)this.so2); i ++){
            if((int)this.so2 % i ==0) return false;
        }
        return true;
   }
}
