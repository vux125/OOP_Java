/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vu
 */
import com.mycompany.mavenproject1.J05006;
import java.util.*;

public class main {
    public static Scanner sca = new Scanner(System.in);
    public static void main(String[] args){
        int t = sca.nextInt();
        sca.nextLine();
        ArrayList<J05006> employees = new ArrayList<J05006>();
        for(int i=1 ; i<= t ;i++){
            employees.add(new J05006(i, sca.nextLine(),sca.nextLine(),sca.nextLine(),sca.nextLine(), sca.nextLine(),sca.nextLine()));
        }
        for(J05006 employee:employees){
            System.out.println(employee);
        }
    }
}
