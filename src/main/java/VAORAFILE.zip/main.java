/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Vu
 */
import java.util.*;
import java.text.*;
import java.io.*;

public class main {
    public static void main(String[] args) throws IOException, ClassNotFoundException{
        ObjectInputStream input = new ObjectInputStream(new FileInputStream("DAYSO.DAT"));
        ArrayList<Integer> arr = (ArrayList<Integer>) input.readObject();
        Set<Integer> st = new TreeSet<>();
        
        for(Integer in:arr){
            if(in >= 100 && isPrime(in)==true){
                st.add(in);
            }
        }
        
        for(Integer in:st){
            System.err.println(in);
        }
    }   
    public static boolean isPrime(int n){
        if(n< 2){
            return false;
        }
        for(int i=2;i<=Math.sqrt(n);i++){
            if(n % i == 0){
                return false;
            }
        }
        return true;
    }
}

