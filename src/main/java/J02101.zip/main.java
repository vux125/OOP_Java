/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vu
 */
import com.mycompany.mavenproject1.J02101;
import java.util.*;

public class main {
    public static Scanner sca = new Scanner(System.in);
    public static void main(String[] args){
        int t = sca.nextInt();
        while (t-- > 0){
            int n = sca.nextInt();
            int a[][] = new int[n][n];
            for(int i=0;i<n;i++){
                for(int j=0;j<n;j++){
                    a[i][j] = sca.nextInt();
                }
            }
            J02101.matrix(a, n);
        }
    }
}
