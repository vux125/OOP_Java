/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Vu
 */
import java.util.*;
import java.text.*;
import java.io.*;

public class J07010 {
    private String msv, name, cls;
    private Date birth;
    private String gpa;

    
    public J07010(int n, String name, String cls, String birth, float gpa){
        this.msv = "B20DCCN" + String.format("%03d", n);
        this.name = name;
        this.cls = cls;
        try{
            this.birth = new SimpleDateFormat("dd/MM/yyyy").parse(birth);
        }catch(Exception e){
        }
        this.gpa = String.format("%.2f",gpa);
    }
    
    @Override 
    public String toString(){
        SimpleDateFormat spf = new SimpleDateFormat("dd/MM/yyyy");
        return this.msv+" "+this.name+" "+this.cls+" "+spf.format(this.birth)+" "+this.gpa;
    }
}

