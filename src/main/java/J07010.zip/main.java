/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Vu
 */
import java.util.*;
import java.text.*;
import java.io.*;
import com.mycompany.mavenproject1.J07010;

public class main {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("SV.in"));
        int n = sc.nextInt();
        sc.nextLine();
        ArrayList<J07010> arr = new ArrayList<J07010>();
        int i =1;
        while(n-- > 0){
            while(sc.hasNextLine()){
                String name = sc.nextLine();
                String cls = sc.nextLine(); 
                String birth = sc.nextLine();
                float gpa = Float.parseFloat(sc.nextLine());          
                arr.add(new J07010(i, name, cls, birth, gpa));
                i++;
            }    
            
        }
        for(J07010 ar : arr){
            System.out.println(ar);
        }
        
    }   
}

